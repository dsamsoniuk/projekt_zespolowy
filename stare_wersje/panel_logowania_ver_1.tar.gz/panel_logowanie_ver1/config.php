<?php


/***************************************************************
 * Panel konfiguracyjna 
 ***************************************************************/



/*******************************    Dane o serwerze      ******************************/

$server_name = "localhost";        // Nazwa Serwera
$user_name = "root";               // Nazwa uzytkownika
$password = "";                    // Haslo uzytkownika
$server_db = "projekt_z";          // Nazwa bazy danych
	
	
	
	
	
	
?>